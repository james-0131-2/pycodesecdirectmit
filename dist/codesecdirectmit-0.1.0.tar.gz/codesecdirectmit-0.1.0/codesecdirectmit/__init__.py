from .module1 import my_function

__all__ = ["my_function"]
