def my_function():
    print(11111)
